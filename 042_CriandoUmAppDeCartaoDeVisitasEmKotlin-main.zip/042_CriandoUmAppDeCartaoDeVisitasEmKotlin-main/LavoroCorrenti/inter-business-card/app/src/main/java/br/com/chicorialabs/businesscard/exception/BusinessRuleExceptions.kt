package br.com.chicorialabs.businesscard.exception

class InvalidNameException(s: String) : Exception(s)
